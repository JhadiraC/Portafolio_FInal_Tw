
package proyectofinal;

public interface Vendible {
     double obtenerPrecio();
    
}
