package proyectofinal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import java.util.Arrays;
import java.util.Date;

public class Catalogo {

    private static final String URL = "jdbc:mysql://localhost:3306/poo_final";
    private static final String USUARIO = "root";
    private static final String CONTRASEÑA = "12345";
    private Connection conexion;


    private Disco[] discos;
    private int[] cantidades;
    private boolean[] estados;
    private int capacidad;
    private int cantidadDiscos;
    // instumentos
    private Instrumentos[] instrumento;
    private int cantidadInstrumentos;

    public Catalogo(int capacidad) {
        this.capacidad = capacidad;
        discos = new Disco[capacidad];
        instrumento = new Instrumentos[capacidad];
        cantidades = new int[capacidad];

        estados = new boolean[capacidad];
        cantidadDiscos = 0;
        cantidadInstrumentos = 0;
         try {
            establecerConexion();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejar el error de conexión aquí
        }

    }
    public Disco[] getDiscos() {
        return discos;
    }

    public Instrumentos[] getInstrumento() {
        return instrumento;
    }

    public int[] getCantidades() {
        return cantidades;
    }

    public boolean[] getEstados() {
        return estados;
    }

    public int getCantidadInstrumentos() {
        return cantidadInstrumentos;
    }

    public void setCantidadInstrumentos(int cantidadInstrumentos) {
        this.cantidadInstrumentos = cantidadInstrumentos;
    }
 private void establecerConexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);
            if (conexion != null) {
                System.out.println("Conexion a la base de datos establecida.");
            } else {
                System.out.println("No se pudo establecer la conexión a la base de datos.");
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Error cargando el controlador JDBC", e);
        }
    }
    public void agregarDisco(Disco disco, int cantidad, boolean agotado) {
        if (cantidadDiscos < capacidad) {
            discos[cantidadDiscos] = disco;
            cantidades[cantidadDiscos] = cantidad;
            estados[cantidadDiscos] = agotado;
            cantidadDiscos++;
        } else {
            System.out.println("El catalogo está lleno. No se puede agregar mas discos.");
        }
    }
 
    public void agregarDiscoAlCatalogoEnBD(Disco disco, int cantidad, boolean agotado) {
        try (Connection connection = ConexionMySQL.obtenerConexion()) {
            // Utilizar PreparedStatement para evitar inyección de SQL
            String sql = "INSERT INTO catalogo_discos (idDisco, cantidad, agotado) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, disco.getCodigoDisco());
                pstmt.setInt(2, cantidad);
                pstmt.setBoolean(3, agotado);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar la excepción de manera apropiada (lanzar o loggear, según el caso)
        }
    }
 

public List<Disco> obtenerDiscosDesdeBD() {
    List<Disco> discos = new ArrayList<>();
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "SELECT discos.codigoDisco, discos.nombreDisco, artistas.nombre AS nombreArtista, artistas.dni AS dniArtista, artistas.nacionalidad AS nacionalidadArtista FROM discos JOIN artistas ON discos.idArtista = artistas.dni";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    int codigoDisco = resultSet.getInt("codigoDisco");
                    String nombreDisco = resultSet.getString("nombreDisco");

                    // Información del artista
                    String dniArtista = resultSet.getString("dniArtista");
                    String nombreArtista = resultSet.getString("nombreArtista");
                    String nacionalidadArtista = resultSet.getString("nacionalidadArtista");
                    Artista artista = new Artista(dniArtista, nombreArtista, nacionalidadArtista);

                    // Crea un objeto Disco y agrégalo a la lista
                    Disco disco = new Disco(codigoDisco, nombreDisco, artista);
                    discos.add(disco);
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return discos;
}
public void agregarInstrumentoAlCatalogoEnBD(Instrumentos instrumento, int cantidad, boolean agotado) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "INSERT INTO catalogo_instrumentos (codigo, cantidad, agotado) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, instrumento.getCodigo());
            pstmt.setInt(2, cantidad);
            pstmt.setBoolean(3, agotado);
            pstmt.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Manejar la excepción de manera apropiada
    }
}
public List<Instrumentos> obtenerInstrumentosDesdeBD() {
    List<Instrumentos> instrumentos = new ArrayList<>();
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "SELECT * FROM instrumentos";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    // Obtén los datos del instrumento desde la base de datos
                    int codigo = resultSet.getInt("codigo");
                    String nombre = resultSet.getString("nombre");
                    String fabricacion = resultSet.getString("fabricacion");
                    int antiguedad = resultSet.getInt("antiguedad");
                    double precio = resultSet.getDouble("precio");
                    String tipoInstrumento = resultSet.getString("tipo_instrumento");
                    int cantidadStock = resultSet.getInt("cantidad_stock");

                    // Crea un objeto Instrumentos y agrégalo a la lista
                    Instrumentos instrumento = new Instrumentos(nombre, fabricacion, antiguedad, precio, tipoInstrumento, cantidadStock, codigo);
                    instrumentos.add(instrumento);
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return instrumentos;
}

    public void agregarInstrumento(Instrumentos instrumentos, int cantidad, boolean agotado) {
        if (cantidadInstrumentos < capacidad) {
            instrumento[cantidadInstrumentos] = instrumentos;
            cantidades[cantidadInstrumentos] = cantidad;
            estados[cantidadInstrumentos] = agotado;
            cantidadInstrumentos++;
        } else {
            System.out.println("El catálogo está lleno. No se puede agregar más instrumentos.");
        }
    }

    public void eliminarInstrumento(Instrumentos instrumentos) {
        for (int i = 0; i < cantidadInstrumentos; i++) {
            if (instrumento[i].equals(instrumento)) {
                instrumento[i] = instrumento[cantidadInstrumentos - 1];
                cantidades[i] = cantidades[cantidadInstrumentos - 1];
                estados[i] = estados[cantidadInstrumentos - 1];
                instrumento[cantidadInstrumentos - 1] = null;
                cantidades[cantidadInstrumentos - 1] = 0;
                estados[cantidadInstrumentos - 1] = false;
                cantidadInstrumentos--;
                break;
            }
        }
    }

    //este metodo permite eliminar un disco específico del catalogo. Busca el disco en el 
    //arreglo discos lo encuentra y, lo elimina
    public void eliminarDisco(Disco disco) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].equals(disco)) {
                discos[i] = discos[cantidadDiscos - 1];
                cantidades[i] = cantidades[cantidadDiscos - 1];
                estados[i] = estados[cantidadDiscos - 1];
                discos[cantidadDiscos - 1] = null;
                cantidades[cantidadDiscos - 1] = 0;
                estados[cantidadDiscos - 1] = false;
                cantidadDiscos--;
                break;
            }
        }
    }

    //permite obtener la cantidad de copias disponibles de un disco específico en el 
    //catalogo. Recorre los discos en el catalogo
    public int obtenerCantidad(Disco disco) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].equals(disco)) {
                return cantidades[i];
            }
        }
        return 0;
    }


  
    public void actualizarCantidad(Disco disco, int nuevaCantidad) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].equals(disco)) {
                cantidades[i] = nuevaCantidad;
                break;
            }
        }
    }

    public void actualizarCantidadInstrumento(Instrumentos instrumentos, int nuevaCantidad) {
        for (int i = 0; i < cantidadInstrumentos; i++) {
            if (instrumento[i].equals(instrumentos)) {
                cantidades[i] = nuevaCantidad;
                break;
            }
        }
    }


      public int obtenerCantidad(Instrumentos instrumentos) {
        for (int i = 0; i < cantidadInstrumentos; i++) {
            if (instrumento[i].equals(instrumentos)) {
                return cantidades[i];
            }
        }
        return 0;
    }
    public Instrumentos buscarInstrumentoPorCodigo(int codigo) {
        for (int i = 0; i < cantidadInstrumentos; i++) {
            if (instrumento[i].getCodigo() == codigo) {
                return instrumento[i];
            }
        }
        return null; // Instrumento no encontrado
    }

    public Disco buscarDiscoPorCodigo(int codigo) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].getCodigoDisco() == codigo) {
                return discos[i];
            }
        }
        return null; // Disco no encontrado
    }
        public boolean estaAgotado(Disco disco) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].equals(disco)) {
                return estados[i];
            }
        }
        return false;
    }

    public void mostrarCatalogo() {
    System.out.println("Catálogo de Discos:");
    
    // Mostrar discos registrados en la ejecución de Java
    System.out.println("Discos en la ejecución de Java:");
    for (int i = 0; i < cantidadDiscos; i++) {
        System.out.println(discos[i]); // Asumiendo que Disco tiene un método toString
    }

    // Mostrar discos registrados en la base de datos
    System.out.println("\nDiscos en la base de datos:");
    List<Disco> discosDesdeBD = obtenerDiscosDesdeBD();
    for (Disco disco : discosDesdeBD) {
        System.out.println(disco); // Asumiendo que Disco tiene un método toString
    }
}
      public void actualizarEstado(Disco disco, boolean agotado) {
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i].equals(disco)) {
                estados[i] = agotado;
                break;
            }
        }
    }

    @Override
    public String toString() {
        // Implementar el método toString para visualizar el estado del catálogo
        // Puedes mostrar discos, instrumentos, cantidades, estados, etc.
        return "Catálogo: " + Arrays.toString(discos);
    }

}
