package proyectofinal;

public class Cancion {

    private int numeroCancion;
    private String nombreCancion;
    private double duracion;

//este constructor se utiliza para crear un objeto cancion con la información proporcionada
    public Cancion(int numeroCancion, String nombreCancion, double duracion) {
        this.numeroCancion = numeroCancion;
        this.nombreCancion = nombreCancion;
        this.duracion = duracion;
    }
// Getters y setters para los atributos

    public int getNumeroCancion() {
        return numeroCancion;
    }

    public void setNumeroCancion(int numeroCancion) {
        this.numeroCancion = numeroCancion;
    }

    public String getNombreCancion() {
        return nombreCancion;
    }

    public void setNombreCancion(String nombreCancion) {
        this.nombreCancion = nombreCancion;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }
//se utiliza para obtener una representación en forma de cadena (String) del objeto. 
//Cancion que muestra sus atributos numeroCancion, nombreCancion y duracion.

    @Override
    public String toString() {
        return "Cancion [numeroCancion=" + numeroCancion + ", nombreCancion=" + nombreCancion + ", duracion=" + duracion
                + "]";
    }
}
