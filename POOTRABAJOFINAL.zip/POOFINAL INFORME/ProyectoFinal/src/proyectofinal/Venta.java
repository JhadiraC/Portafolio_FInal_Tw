package proyectofinal;

public class Venta {

    private int codigoVenta;
    private Disco[] discosVenta;
    private double montoTotal;
    private String fechaVenta;

//este constructor se utiliza para crear un objeto venta con la información proporcionada
    public Venta(int codigoVenta, Disco[] discosVenta, double montoTotal, String fechaVenta) {
        this.codigoVenta = codigoVenta;
        this.discosVenta = discosVenta;
        this.montoTotal = montoTotal;
        this.fechaVenta = fechaVenta;
    }

// Getters y setters para los atributos
    public int getCodigoVenta() {
        return codigoVenta;
    }

    public void setCodigoVenta(int codigoVenta) {
        this.codigoVenta = codigoVenta;
    }

    public Disco[] getDiscosVenta() {
        return discosVenta;
    }

    public void setDiscosVenta(Disco[] discosVenta) {
        this.discosVenta = discosVenta;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }
}
