package proyectofinal;

public class Disco implements Vendible {

    private int codigoDisco;
    private String nombreDisco;
    private Artista artista;
    private String[] listaCanciones;
    private int cantidadCanciones;
    private double precio;
    

    public Disco(int codigoDisco, String nombreDisco, Artista artista) {
        this.codigoDisco = codigoDisco;
        this.nombreDisco = nombreDisco;
        this.artista = artista;
        this.listaCanciones = new String[10]; // Inicializar el array en tamaño 7
        this.cantidadCanciones = 0;
        this.precio = 0.0;
    }


    // Getters y setters para los atributos
    public int getCodigoDisco() {
        return codigoDisco;
    }

    public void setCodigoDisco(int codigoDisco) {
        this.codigoDisco = codigoDisco;
    }

    public String getNombreDisco() {
        return nombreDisco;
    }

    public void setNombreDisco(String nombreDisco) {
        this.nombreDisco = nombreDisco;
    }

    public Artista getArtista() {
        return artista;
    }

    public void setArtista(Artista artista) {
        this.artista = artista;
    }

    public String[] getListaCanciones() {
        return listaCanciones;
    }

    public double getPrecio() {
        return precio;
    }

    // Metodos
    public void agregarCancion(String cancion) {
        if (cantidadCanciones >= listaCanciones.length) {
            redimensionarListaCanciones(); // Ajusta el tamaño del array
        }
        listaCanciones[cantidadCanciones] = cancion;
        cantidadCanciones++;
    }

    public void eliminarCancion(String cancion) {
        int indice = -1;
        for (int i = 0; i < cantidadCanciones; i++) {
            if (listaCanciones[i].equals(cancion)) {
                indice = i;
                break;
            }
        }
        if (indice != -1) {
            // Mover las canciones hacia atras para llenar el espacio vacip
            for (int j = indice; j < cantidadCanciones - 1; j++) {
                listaCanciones[j] = listaCanciones[j + 1];
            }
            listaCanciones[cantidadCanciones - 1] = null;
            cantidadCanciones--;
        }
    }

    // M. obtener la cantidad de canciones en el disco
    public int getCantidadCanciones() {
        return cantidadCanciones;
    }

    // M. redimensiona el array de canciones
    private void redimensionarListaCanciones() {
        String[] nuevaListaCanciones = new String[cantidadCanciones * 2];
        for (int i = 0; i < cantidadCanciones; i++) {
            nuevaListaCanciones[i] = listaCanciones[i];
        }
        listaCanciones = nuevaListaCanciones;
    }

    @Override
    public double obtenerPrecio() {
        return this.precio;
    }

    public void establecerPrecio(double precio) {
        this.precio = precio;
    }

}
