
package proyectofinal;

public interface Serializable {
    
}
