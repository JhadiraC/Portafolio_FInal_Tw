
package proyectofinal;

public class Artista {
    private String dni;
    private String nombre;
    private String nacionalidad;
    private Disco[] discos;
    private int cantidadDiscos;
    
//este constructor se utiliza para crear un objeto artista con la información proporcionada
    
    public Artista(String dni, String nombre, String nacionalidad) {
        this.dni = dni;
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.discos = new Disco[10]; // Establecer un tamaño inicial de 10
        this.cantidadDiscos = 0;
    }

    // Getters y setters para los atributos
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public Disco[] getDiscos() {
        return discos;
    }

    public void agregarDisco(Disco disco) {
        if (cantidadDiscos < discos.length) {
            discos[cantidadDiscos] = disco;
            cantidadDiscos++;
        } else {
            
            System.out.println("No se pueden agregar más discos al artista.");
        }
    }
    
//este codigo solo busca el objeto disco en el arreglo y determina su indice.
    public void eliminarDisco(Disco disco) {
        int indice = -1;
        for (int i = 0; i < cantidadDiscos; i++) {
            if (discos[i] == disco) {
                indice = i;
                break;
            }
        }
        
        //este codigo elimina el objeto disco del arreglo discos si existe en el arreglo
        if (indice != -1) {
            // Mover los discos hacia atrás para llenar el espacio vacío
            for (int j = indice; j < cantidadDiscos - 1; j++) {
                discos[j] = discos[j + 1];
            }
            discos[cantidadDiscos - 1] = null;
            cantidadDiscos--;
        }    }  
}
