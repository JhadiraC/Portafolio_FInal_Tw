package proyectofinal;

import java.sql.Statement;
import java.io.IOException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Principal {

    private static Scanner scanner = new Scanner(System.in);

    private static Artista[] artistasTotal = new Artista[100];
    private static Cancion[] cancionesTotal = new Cancion[200];
    private static Disco[] discosTotal = new Disco[200];
    private static Catalogo catalogoTotal = new Catalogo(600);
    private static Venta[] ventasTotal = new Venta[100];
    private static Instrumentos[] instrumentosTotal = new Instrumentos[10];
    private static double montoTotal = 0.0;
    private static String tipoInstrumento;

    public static void main(String[] args) throws IOException {

        int opcion;
        do {
            mostrarMenu();
            System.out.print("Ingrese una opcion: ");

            try {
                opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        registrarArtista();
                        break;
                    case 2:
                        registrarCanciones();
                        break;
                    case 3:
                        registrarDisco();
                        break;
                    case 4:
                        registrarInstrumentos();
                        break;
                    case 5:
                        agregarDiscoAlCatalogo();
                        break;
                    case 6:
                        agregarInstrumentosAlCatalogo();
                        break;
                    case 7:
                        eliminarInstrumentosDelCatalogo();
                        break;
                    case 8:
                        eliminarDiscoDelCatalogo();
                        break;
                    case 9:
                        venderDisco();
                        break;
                    case 10:
                        venderInstrumentos();
                        break;
                    case 11:
                        generarReporteInstrumentos();
                        break;
                    case 12:
                        generarReporteArtistas();
                        break;
                    case 13:
                        generarReporteCanciones();
                        break;
                    case 14:
                        generarReporteDiscos();
                        break;
                    case 15:
                        generarReporteMontoRecaudado();
                        break;
                    case 16:

                        System.out.println("Gracias por usar el sistema...Buen dia.");
                        break;

                    default:
                        System.out.println("Opcion invalida. Ingrese una opcion valida...");
                }

            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un valor numerico valido.");
                scanner.nextLine();
                opcion = 0;
            }

        } while (opcion != 16);
    }
//simplemente muestra en pantalla el menu principal del sistema, con todas las opciones 
//disponibles para que el usuario pueda elegir qué acción desea realizar. Cada opcion está 
//numerada y corresponde a una funcionalidad específica del programa.

    private static void mostrarMenu() {
        System.out.println("----------------------------------------------------");
        System.out.println("\nSISTEMA DE OPERACIONES DE LA TIENDA <<EL PIRATIN>>");
        System.out.println("\n---------------- Menu Principal ---------------");
        System.out.println("1.  Registrar Artista");
        System.out.println("2.  Registrar Canciones");
        System.out.println("3.  Registrar Disco");
        System.out.println("4.  Registrar Instrumento");
        System.out.println("5.  Agregar Disco al Catalogo");
        System.out.println("6.  Agregar Instrumento al Catalogo");
        System.out.println("7.  Eliminar Instrumento del Catalogo");
        System.out.println("8.  Eliminar Disco del Catalogo");
        System.out.println("9.  Vender Disco");
        System.out.println("10. Vender Instrumentos");
        System.out.println("11. Generar Reporte de Instrumentos");
        System.out.println("12. Generar Reporte de Artistas");
        System.out.println("13. Generar Reporte de Canciones");
        System.out.println("14. Generar Reporte de Discos");
        System.out.println("15. Generar Reporte de Monto Recaudado");
        System.out.println("16. Salir");
        System.out.println("-----------------------------------------------");
    }

    //permite registrar un nuevo artista al solicitar información como el DNI, el nombre y 
    //la nacionalidad, para luego crear un objeto Artista y almacenarlo en un arreglo de artistas 
    //  llamado artistasTotal
    private static void registrarArtista() {
        String dni = "";
        String nombre = "";
        String nacionalidad = "";
        do {
            System.out.println("\n\t----- Registrar Artista -----");

            boolean dniValido = false;
            do {
                System.out.print("Ingrese el DNI del artista: ");
                try {
                    dni = scanner.nextLine();

                    // DNI sea entero.
                    int dniNumero = Integer.parseInt(dni);

                    // DNI tenga 8 digitos.
                    if (dni.length() != 8) {
                        throw new IllegalArgumentException("Error: El DNI debe tener exactamente 8 digitos.");
                    }

                    dniValido = true;
                } catch (NumberFormatException e) {
                    System.out.println("Error: El DNI debe ser un numero entero.");
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!dniValido);

            boolean nombreValido = false;
            do {
                System.out.print("Ingrese el nombre del artista: ");
                try {
                    nombre = scanner.nextLine();

                    if (!nombre.matches("^[a-zA-Z]+$")) {
                        throw new IllegalArgumentException("Error: El nombre solo puede contener letras.");
                    }

                    if (nombre.isEmpty()) {
                        throw new IllegalArgumentException("Error: El nombre no puede estar vacio.");
                    }

                    nombreValido = true;
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!nombreValido);

            boolean nacionalidadValida = false;
            do {
                System.out.print("Ingrese la nacionalidad del artista: ");
                try {
                    nacionalidad = scanner.nextLine();

                    if (!nacionalidad.matches("^[a-zA-Z]+$")) {
                        throw new IllegalArgumentException("Error: La nacionalidad solo puede contener letras.");
                    }

                    if (nacionalidad.isEmpty()) {
                        throw new IllegalArgumentException("Error: La nacionalidad no puede estar vacia.");
                    }

                    nacionalidadValida = true;
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!nacionalidadValida);

            Artista artista = new Artista(dni, nombre, nacionalidad);
            artistasTotal[obtenerIndiceDisponible(artistasTotal)] = artista;
            System.out.println("Artista registrado con exito.");

            System.out.println("Desea registrar otro artista? (s/n): ");
            String opcion = scanner.nextLine().trim().toLowerCase();

            if (!opcion.equals("s")) {
                break;
            }
        } while (true);
        try {
            // Establecer conexión con la base de datos
            Connection connection = obtenerConexion();

            // Preparar la sentencia SQL para la inserción
            String sql = "INSERT INTO artistas (dni, nombre, nacionalidad) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                // Establecer los parámetros de la sentencia
                pstmt.setString(1, dni);
                pstmt.setString(2, nombre);
                pstmt.setString(3, nacionalidad);

                // Ejecutar la inserción
                pstmt.executeUpdate();

                System.out.println("Artista registrado en la base de datos con éxito.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Connection obtenerConexion() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/poo_final";
        String usuario = "root";
        String contraseña = "12345";
        return DriverManager.getConnection(url, usuario, contraseña);
    }

    private static void registrarCanciones() {
        System.out.println("\n----- Registrar Canciones -----");
        int cantidadCanciones = 0;

        boolean cantidadValida = false;
        do {
            System.out.print("Ingrese la cantidad de canciones a registrar: ");
            try {
                cantidadCanciones = scanner.nextInt();
                scanner.nextLine();

                if (cantidadCanciones <= 0) {
                    throw new IllegalArgumentException("Error: La cantidad de canciones debe ser mayor a cero.");
                }

                cantidadValida = true;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un numero entero valido.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!cantidadValida);

        // Ahora procedemos a registrar las canciones.
        for (int i = 0; i < cantidadCanciones; i++) {
            System.out.println("Cancion #" + (i + 1));

            boolean numeroCancionValido = false;
            int numeroCancion = 0;
            do {
                System.out.print("Ingrese el numero de la cancion: ");
                try {
                    numeroCancion = scanner.nextInt();
                    scanner.nextLine();

                    numeroCancionValido = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un numero entero valido.");
                    scanner.nextLine();
                }
            } while (!numeroCancionValido);

            boolean nombreCancionValido = false;
            String nombreCancion = "";
            do {
                System.out.print("Ingrese el nombre de la cancion: ");
                nombreCancion = scanner.nextLine();

                try {
                    if (!nombreCancion.matches("^[a-zA-Z ]+$")) {
                        throw new IllegalArgumentException("Error: El nombre de la canción solo puede contener letras.");
                    }

                    if (nombreCancion.isEmpty()) {
                        throw new IllegalArgumentException("Error: El nombre de la cancion no puede estar vacio.");
                    }

                    nombreCancionValido = true;
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!nombreCancionValido);

            boolean duracionValida = false;
            double duracion = 0;
            do {
                System.out.print("Ingrese la duracion de la cancion (en minutos): ");
                try {
                    duracion = scanner.nextDouble();
                    scanner.nextLine();

                    duracionValida = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un numero valido para la duracion.");
                    scanner.nextLine();
                }
            } while (!duracionValida);

            Cancion nuevaCancion = new Cancion(numeroCancion, nombreCancion, duracion);

            // Agregar la canción al array
            cancionesTotal[obtenerIndiceDisponible(cancionesTotal)] = nuevaCancion;
            System.out.println("Cancion registrada con exito.");

            // Insertar la canción en la base de datos
            insertarCancionEnBD(nuevaCancion);
        }
    }

    private static void insertarCancionEnBD(Cancion cancion) {
        try (Connection connection = obtenerConexion()) {
            String sql = "INSERT INTO canciones (numeroCancion, nombreCancion, duracion) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, cancion.getNumeroCancion());
                pstmt.setString(2, cancion.getNombreCancion());
                pstmt.setDouble(3, cancion.getDuracion());

                // Ejecutar la inserción
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //permite al usuario registrar un nuevo disco en el sistema, solicitando datos como el codigo 
    //del disco, su nombre, el artista asociado y las canciones que lo componen. También maneja 
    //casos en los que el artista o la cancion seleccionada no se encuentren en el sistema, y 
    //finalmente muestra un mensaje de éxito 
    private static void registrarDisco() {
        System.out.println("\n----- Registrar Disco -----");

        // Lógica para ingresar el código del disco
        boolean codigoDiscoValido = false;
        int codigoDisco = 0;
        do {
            System.out.print("Ingrese el codigo del disco: ");
            try {
                String inputCodigo = scanner.nextLine();
                if (inputCodigo.isEmpty()) {
                    throw new IllegalArgumentException("Error: El codigo del disco no puede estar vacio.");
                }

                if (!inputCodigo.matches("^[a-zA-Z0-9]+$")) {
                    throw new IllegalArgumentException("Error: El codigo del disco solo puede contener letras y numeros, sin espacios.");
                }

                codigoDisco = Integer.parseInt(inputCodigo);
                codigoDiscoValido = true;
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero valido para el codigo del disco...");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!codigoDiscoValido);

        // Lógica para ingresar el nombre del disco
        boolean nombreDiscoValido = false;
        String nombreDisco = "";
        do {
            System.out.print("Ingrese el nombre del disco: ");
            try {
                nombreDisco = scanner.nextLine();

                if (!nombreDisco.matches("^[a-zA-Z ]+$")) {
                    throw new IllegalArgumentException("Error: El nombre del disco solo puede contener letras.");
                }

                if (nombreDisco.isEmpty()) {
                    throw new IllegalArgumentException("Error: El nombre del disco no puede estar vacío.");
                }

                nombreDiscoValido = true;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!nombreDiscoValido);

        // Mostrar la lista de artistas
        System.out.println("Lista de artistas:");
        mostrarArtistasDesdeBaseDeDatos();
        for (int i = 0; i < artistasTotal.length; i++) {
            Artista artista = artistasTotal[i];
            if (artista != null) {
                System.out.println((i + 1) + ". " + artista.getNombre());
            }
        }

        // Lógica para seleccionar el artista del disco
        boolean numeroArtistaValido = false;
        int numeroArtista = 0;
        do {
            System.out.print("Seleccione el numero del artista del disco: ");
            try {
                numeroArtista = scanner.nextInt();
                scanner.nextLine();

                if (numeroArtista <= 0 || numeroArtista > artistasTotal.length) {
                    throw new IllegalArgumentException("Error: Seleccione un numero valido del artista.");
                }

                numeroArtistaValido = true;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un numero entero valido.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!numeroArtistaValido);

        // Obtener el artista seleccionado desde la base de datos
        Artista artistaSeleccionado = obtenerArtistaDesdeBaseDeDatos(numeroArtista);

        if (artistaSeleccionado != null) {
            // Crear una instancia de Disco
            Disco disco = new Disco(codigoDisco, nombreDisco, artistaSeleccionado);

            // Establecer el precio del disco
            System.out.print("Ingrese el precio del disco: $");
            double precioDisco = scanner.nextDouble();
            scanner.nextLine();

            disco.establecerPrecio(precioDisco);

            System.out.println("\nAgregue las canciones al disco (ingrese '0' para terminar):");
            int numeroCancion = 0;
            do {
                // Mostrar la lista de canciones
                System.out.println("Lista de canciones:");
                mostrarCancionesDesdeBaseDeDatos();
                for (int i = 0; i < cancionesTotal.length; i++) {
                    Cancion cancion = cancionesTotal[i];
                    if (cancion != null) {
                        System.out.println((i + 1) + ". " + cancion.getNombreCancion());
                    }
                }

                // Lógica para seleccionar la canción y agregarla al disco
                boolean numeroCancionValido = false;
                do {
                    System.out.print("Ingrese el numero de la cancion a agregar (o '0' para terminar): ");
                    try {
                        numeroCancion = scanner.nextInt();
                        scanner.nextLine();

                        if (numeroCancion == 0) {
                            break; // Salimos del bucle si el usuario ingresa 0 para terminar de agregar canciones.
                        }

                        if (numeroCancion <= 0 || numeroCancion > cancionesTotal.length) {
                            throw new IllegalArgumentException("Error: Seleccione un numero valido de la cancion.");
                        }

                        numeroCancionValido = true;
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Ingrese un numero entero valido.");
                        scanner.nextLine();
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                } while (!numeroCancionValido);

                // Agregar la canción al disco
                if (numeroCancion != 0) {
                    Cancion cancion = buscarCancionPorNumero(numeroCancion);
                    if (cancion != null) {
                        disco.agregarCancion(cancion.getNombreCancion());
                        System.out.println("Cancion agregada al disco.");
                    } else {
                        System.out.println("Cancion no encontrada.");
                    }
                }
            } while (numeroCancion != 0);

            // Agregar el disco al array de discos
            discosTotal[obtenerIndiceDisponible(discosTotal)] = disco;
            System.out.println("Disco registrado con exito.");

            // Insertar el disco en la base de datos
            insertarDiscoEnBD(disco);
        } else {
            System.out.println("Artista no encontrado.");
        }
    }

    private static void mostrarCancionesDesdeBaseDeDatos() {
        try (Connection connection = obtenerConexion()) {
            String sql = "SELECT * FROM canciones";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = pstmt.executeQuery()) {
                    while (resultSet.next()) {
                        int numeroCancion = resultSet.getInt("numeroCancion");
                        String nombreCancion = resultSet.getString("nombreCancion");
                        double duracion = resultSet.getDouble("duracion");

                        System.out.println("Número de Canción: " + numeroCancion);
                        System.out.println("Nombre de Canción: " + nombreCancion);
                        System.out.println("Duración: " + duracion);
                        System.out.println("------------------------");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertarDiscoEnBD(Disco disco) {
        try (Connection connection = obtenerConexion()) {
            // Insertar el disco en la tabla de discos
            String sqlDisco = "INSERT INTO discos (codigoDisco, nombreDisco, idArtista, precio) VALUES (?, ?, ?, ?)";

            try (PreparedStatement pstmtDisco = connection.prepareStatement(sqlDisco, Statement.RETURN_GENERATED_KEYS)) {
                pstmtDisco.setInt(1, disco.getCodigoDisco());
                pstmtDisco.setString(2, disco.getNombreDisco());
                pstmtDisco.setString(3, disco.getArtista().getDni());
                pstmtDisco.setDouble(4, disco.getPrecio());

                // Ejecutar la inserción y obtener el ID generado
                int affectedRows = pstmtDisco.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("No se pudo insertar el disco, ninguna fila afectada.");
                }

                try (ResultSet generatedKeys = pstmtDisco.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int idDisco = generatedKeys.getInt(1);
                        // Insertar las canciones del disco en la tabla de canciones_discos
                        for (String nombreCancion : disco.getListaCanciones()) {
                            insertarCancionDiscoEnBD(idDisco, nombreCancion);
                        }
                    } else {
                        throw new SQLException("No se pudo obtener el ID generado para el disco.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertarCancionDiscoEnBD(int idDisco, String nombreCancion) {
        try (Connection connection = obtenerConexion()) {
            // Buscar la canción por nombre en la tabla de canciones
            String sqlBuscarCancion = "SELECT numeroCancion FROM canciones WHERE nombreCancion = ?";
            try (PreparedStatement pstmtBuscarCancion = connection.prepareStatement(sqlBuscarCancion)) {
                pstmtBuscarCancion.setString(1, nombreCancion);

                try (ResultSet resultSet = pstmtBuscarCancion.executeQuery()) {
                    if (resultSet.next()) {
                        int numeroCancion = resultSet.getInt("numeroCancion");

                        // Insertar la relación en la tabla de canciones_discos
                        String sqlInsertCancionDisco = "INSERT INTO canciones_discos (idDisco, numeroCancion) VALUES (?, ?)";
                        try (PreparedStatement pstmtInsertCancionDisco = connection.prepareStatement(sqlInsertCancionDisco)) {
                            pstmtInsertCancionDisco.setInt(1, idDisco);
                            pstmtInsertCancionDisco.setInt(2, numeroCancion);
                            pstmtInsertCancionDisco.executeUpdate();
                            System.out.println("Canción agregada al disco exitosamente.");
                        } catch (SQLException e) {
                            e.printStackTrace();
                            System.out.println("Error al insertar la relación en la tabla de canciones_discos.");
                        }
                    } else {
                        System.out.println("Canción no encontrada en la base de datos: " + nombreCancion);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error de conexión a la base de datos.");
        }
    }

    private static Artista obtenerArtistaDesdeBaseDeDatos(int numeroArtista) {
        try (Connection connection = obtenerConexion()) {
            String sql = "SELECT dni, nombre, nacionalidad FROM artistas LIMIT ?, 1";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setInt(1, numeroArtista - 1);
                try (ResultSet resultSet = pstmt.executeQuery()) {
                    if (resultSet.next()) {
                        String dni = resultSet.getString("dni");
                        String nombre = resultSet.getString("nombre");
                        String nacionalidad = resultSet.getString("nacionalidad");

                        return new Artista(dni, nombre, nacionalidad);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static double obtenerPrecioDiscoDesdeBaseDeDatos(int codigoDisco) {
        return 0.0; // Reemplaza esto con la lógica real
    }

    private static void registrarInstrumentos() {
        System.out.println("\n-----Registrar Instrumentos-----");
        // Lógica para solicitar y registrar los detalles del instrumento
        System.out.print("Ingrese el nombre del instrumento: ");
        String nombre = scanner.nextLine();

        int anioFabricacion = 0;
        boolean anioValido = false;
        do {
            System.out.print("Ingrese el anio de fabricacion del instrumento: ");
            try {
                anioFabricacion = scanner.nextInt();
                scanner.nextLine();

                if (anioFabricacion < 0 || anioFabricacion > 2023) {
                    throw new IllegalArgumentException("Error: Ingrese un anio de fabricación valido.");
                }

                anioValido = true;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un anio valido.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!anioValido);

// Calcular la antigüedad
        int antiguedad = 2023 - anioFabricacion;

        System.out.print("Ingrese el precio del instrumento: $");
        double precioInstrumento = scanner.nextDouble();
        scanner.nextLine();  // Limpiar el buffer del scanner

        System.out.print("Ingrese el tipo de instrumento:\n");
        String[] tiposInstrumentos = {"Cuerda", "Viento", "Percusion", "Teclado", "Electronico"};

        // Mostrar la lista de tipos de instrumentos
        for (int i = 0; i < tiposInstrumentos.length; i++) {
            System.out.println((i + 1) + ". " + tiposInstrumentos[i]);
        }

        // Pedir al usuario que elija un tipo
        System.out.print("Ingrese el numero del tipo de instrumento: ");
        int seleccion = -1;
        do {
            try {
                seleccion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer de entrada

                // Verificar que la selección esté en el rango válido
                if (seleccion <= 0 || seleccion > tiposInstrumentos.length) {
                    System.out.println("Error: Seleccione un numero valido.");
                    seleccion = -1; // Reiniciar la selección para que el bucle continúe
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un numero entero valido.");
                scanner.nextLine(); // Limpiar el buffer de entrada
            }
        } while (seleccion == -1);

// Obtener el tipo de instrumento seleccionado
        String tipoInstrumento = tiposInstrumentos[seleccion - 1];
        System.out.println("Tipo de instrumento seleccionado: " + tipoInstrumento);

        boolean cantidadEnStockValida = false;
        int cantidadEnStockInstrumento = 0;
        do {
            System.out.print("Ingrese la cantidad en stock del instrumento: ");
            try {
                cantidadEnStockInstrumento = scanner.nextInt();
                scanner.nextLine();

                if (cantidadEnStockInstrumento < 0) {
                    throw new IllegalArgumentException("Error: La cantidad en stock no puede ser un numero negativo.");
                }

                cantidadEnStockValida = true;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero valido.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!cantidadEnStockValida);

        boolean codigoInstrumentoValido = false;
        int codigoInstrumento = 0;
        do {
            System.out.print("Ingrese el codigo del instrumento: ");
            try {
                String inputCodigoInstrumento = scanner.nextLine();
                if (inputCodigoInstrumento.isEmpty()) {
                    throw new IllegalArgumentException("Error: El código del instrumento no puede estar vacio.");
                }

                if (!inputCodigoInstrumento.matches("^[a-zA-Z0-9]+$")) {
                    throw new IllegalArgumentException("Error: El codigo del instrumento solo puede contener letras y numeros, sin espacios.");
                }

                codigoInstrumento = Integer.parseInt(inputCodigoInstrumento);
                codigoInstrumentoValido = true;
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un número válido para el codigo del instrumento.");
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!codigoInstrumentoValido);
        Instrumentos nuevoInstrumento = new Instrumentos(nombre, "Marca", antiguedad, precioInstrumento, tipoInstrumento, cantidadEnStockInstrumento, codigoInstrumento);

        // Establecer la conexión a la base de datos
        try (Connection connection = obtenerConexion()) {
            // Preparar la sentencia SQL para insertar el instrumento en la base de datos
            String sql = "INSERT INTO instrumentos (nombre, fabricacion, antiguedad, precio, tipo_instrumento, cantidad_stock, codigo) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                // Establecer los parámetros de la sentencia SQL con los valores del nuevoInstrumento
                pstmt.setString(1, nuevoInstrumento.getNombre());
                pstmt.setString(2, nuevoInstrumento.getFabricacion());
                pstmt.setInt(3, nuevoInstrumento.getAntiguedad());
                pstmt.setDouble(4, nuevoInstrumento.getPrecio());
                pstmt.setString(5, nuevoInstrumento.getTipoInstrumento());
                pstmt.setInt(6, nuevoInstrumento.getCantidadStock());
                pstmt.setInt(7, nuevoInstrumento.getCodigo());

                // Ejecutar la sentencia SQL para insertar el nuevo instrumento
                int filasAfectadas = pstmt.executeUpdate();

                // Verificar si se insertó correctamente
                if (filasAfectadas > 0) {
                    System.out.println("Instrumento registrado con éxito en la base de datos.");
                } else {
                    System.out.println("No se pudo registrar el instrumento en la base de datos.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

  private static void agregarDiscoAlCatalogo() {
    System.out.println("\n----- Agregar Disco al Catalogo------");

    List<Disco> discosDisponibles = catalogoTotal.obtenerDiscosDesdeBD();

    if (!discosDisponibles.isEmpty()) {
        System.out.println("Lista de discos disponibles:");
        for (int i = 0; i < discosDisponibles.size(); i++) {
            Disco disco = discosDisponibles.get(i);
            System.out.println((i + 1) + ". Codigo: " + disco.getCodigoDisco() + ", Nombre: " + disco.getNombreDisco());
        }

        boolean numeroDiscoValido = false;
        int numeroDisco = 0;

        do {
            System.out.print("Seleccione el número del disco a agregar al catálogo: ");
            try {
                numeroDisco = scanner.nextInt();
                scanner.nextLine();

                if (numeroDisco <= 0 || numeroDisco > discosDisponibles.size()) {
                    throw new IllegalArgumentException("Error: Seleccione un número válido del disco.");
                }

                numeroDiscoValido = true;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (!numeroDiscoValido);

        Disco discoSeleccionado = discosDisponibles.get(numeroDisco - 1);

        if (discoSeleccionado != null) {
            boolean cantidadValida = false;
            int cantidad = 0;

            do {
                System.out.print("Ingrese la cantidad a agregar al catálogo: ");
                try {
                    cantidad = scanner.nextInt();
                    scanner.nextLine();

                    if (cantidad <= 0) {
                        throw new IllegalArgumentException("Error: La cantidad debe ser mayor a cero.");
                    }

                    cantidadValida = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un número entero válido.");
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!cantidadValida);

            boolean agotadoValido = false;
            boolean agotado = false;

            do {
                System.out.print("¿El disco está agotado? (true/false): ");
                try {
                    String inputAgotado = scanner.nextLine().trim().toLowerCase();

                    if (inputAgotado.isEmpty()) {
                        throw new IllegalArgumentException("Error: Debe ingresar true o false.");
                    }

                    if (inputAgotado.equals("true")) {
                        agotado = true;
                        agotadoValido = true;
                    } else if (inputAgotado.equals("false")) {
                        agotado = false;
                        agotadoValido = true;
                    } else {
                        throw new IllegalArgumentException("Error: Debe ingresar true o false.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!agotadoValido);

            catalogoTotal.agregarDisco(discoSeleccionado, cantidad, agotado);
            guardarDiscoEnBD(discoSeleccionado, cantidad, agotado);
            System.out.println("Disco agregado al catálogo con éxito.");
        } else {
            System.out.println("Disco no encontrado.");
        }
    } else {
        System.out.println("No hay discos registrados para agregar al catálogo.");
    }
}

private static void guardarDiscoEnBD(Disco disco, int cantidad, boolean agotado) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        // Verificar si el disco ya existe en la base de datos
        String sqlVerificar = "SELECT codigoDisco FROM discos WHERE codigoDisco = ?";
        try (PreparedStatement pstmtVerificar = connection.prepareStatement(sqlVerificar)) {
            pstmtVerificar.setInt(1, disco.getCodigoDisco());
            try (ResultSet resultSet = pstmtVerificar.executeQuery()) {
                if (resultSet.next()) {
                    // El disco ya existe, actualizar la cantidad en el catálogo
                    String sqlActualizar = "UPDATE catalogo_discos SET cantidad = cantidad + ?, agotado = ? WHERE idDisco = ?";
                    try (PreparedStatement pstmtActualizar = connection.prepareStatement(sqlActualizar)) {
                        pstmtActualizar.setInt(1, cantidad);
                        pstmtActualizar.setBoolean(2, agotado);
                        pstmtActualizar.setInt(3, disco.getCodigoDisco());
                        pstmtActualizar.executeUpdate();
                        System.out.println("Cantidad del disco actualizada en el catálogo.");
                    }
                } else {
                    // El disco no existe, insertarlo en la tabla discos
                    String sqlInsertarDisco = "INSERT INTO discos (codigoDisco, nombreDisco, idArtista, precio) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstmtInsertarDisco = connection.prepareStatement(sqlInsertarDisco)) {
                        pstmtInsertarDisco.setInt(1, disco.getCodigoDisco());
                        pstmtInsertarDisco.setString(2, disco.getNombreDisco());
                        pstmtInsertarDisco.setString(3, disco.getArtista().getDni());
                        pstmtInsertarDisco.setDouble(4, disco.obtenerPrecio());
                        pstmtInsertarDisco.executeUpdate();
                    }

                    // Insertar el disco en el catálogo
                    String sqlInsertarCatalogo = "INSERT INTO catalogo_discos (idDisco, cantidad, agotado) VALUES (?, ?, ?)";
                    try (PreparedStatement pstmtInsertarCatalogo = connection.prepareStatement(sqlInsertarCatalogo)) {
                        pstmtInsertarCatalogo.setInt(1, disco.getCodigoDisco());
                        pstmtInsertarCatalogo.setInt(2, cantidad);
                        pstmtInsertarCatalogo.setBoolean(3, agotado);
                        pstmtInsertarCatalogo.executeUpdate();
                        System.out.println("Disco agregado al catálogo con éxito.");
                    }
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    private static void agregarInstrumentosAlCatalogo() {
        System.out.println("\n----- Agregar Instrumentos al catálogo ------");

        List<Instrumentos> instrumentosDisponibles = catalogoTotal.obtenerInstrumentosDesdeBD();

        if (!instrumentosDisponibles.isEmpty()) {
            // Muestra lista de instrumentos disponibles
            System.out.println("Lista de instrumentos disponibles:");
            for (int i = 0; i < instrumentosDisponibles.size(); i++) {
                Instrumentos instrumento = instrumentosDisponibles.get(i);
                System.out.println((i + 1) + ". Nombre: " + instrumento.getNombre() + ", Tipo: " + instrumento.getTipoInstrumento());
            }

            boolean numeroInstrumentoValido = false;
            int numeroInstrumento = 0;
            do {
                System.out.print("Seleccione el número del instrumento a agregar al catálogo: ");
                try {
                    numeroInstrumento = scanner.nextInt();
                    scanner.nextLine();

                    if (numeroInstrumento <= 0 || numeroInstrumento > instrumentosDisponibles.size() || instrumentosDisponibles.get(numeroInstrumento - 1) == null) {
                        throw new IllegalArgumentException("Error: Seleccione un número válido del instrumento.");
                    }

                    // Cambiar a true
                    numeroInstrumentoValido = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un número entero válido.");
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!numeroInstrumentoValido);

            Instrumentos instrumentoSeleccionado = instrumentosDisponibles.get(numeroInstrumento - 1);
            if (instrumentoSeleccionado != null) {

                boolean cantidadValida = true;
                int cantidad = 0;
                do {
                    System.out.print("Ingrese la cantidad a agregar al catálogo: ");
                    try {
                        cantidad = scanner.nextInt();
                        scanner.nextLine();

                        if (cantidad <= 0) {
                            throw new IllegalArgumentException("Error: La cantidad debe ser mayor a cero.");
                        }

                        cantidadValida = true;
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Ingrese un número entero válido.");
                        scanner.nextLine();
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                } while (!cantidadValida);

                boolean agotadoValido = false;
                boolean agotado = false;
                do {
                    System.out.print("¿El instrumento está agotado? (true/false): ");
                    try {
                        String inputAgotado = scanner.nextLine().trim().toLowerCase();

                        if (inputAgotado.isEmpty()) {
                            throw new IllegalArgumentException("Error: Debe ingresar true o false.");
                        }

                        if (inputAgotado.equals("true")) {
                            agotado = true;
                            agotadoValido = true;
                        } else if (inputAgotado.equals("false")) {
                            agotado = false;
                            agotadoValido = true;
                        } else {
                            throw new IllegalArgumentException("Error: Debe ingresar true o false.");
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                } while (!agotadoValido);

                // Asumo que la clase Catalogo tiene un método agregarInstrumento similar al agregarDisco
                catalogoTotal.agregarInstrumento(instrumentoSeleccionado, cantidad, agotado);

                // Ahora, agrega la información del instrumento a la base de datos
                guardarInstrumentoEnBD(instrumentoSeleccionado, cantidad, agotado);

                System.out.println("Instrumento agregado al catálogo con éxito.");
            } else {
                System.out.println("Instrumento no encontrado.");
            }
        } else {
            System.out.println("No hay instrumentos registrados para agregar al catálogo.");
        }
    }

   private static void guardarInstrumentoEnBD(Instrumentos instrumento, int cantidad, boolean agotado) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        // Verificar si el instrumento ya existe en la base de datos
        String sqlVerificar = "SELECT codigo FROM tabla_instrumentos WHERE codigo = ?";
        try (PreparedStatement pstmtVerificar = connection.prepareStatement(sqlVerificar)) {
            pstmtVerificar.setInt(1, instrumento.getCodigo());
            try (ResultSet resultSet = pstmtVerificar.executeQuery()) {
                if (resultSet.next()) {
                    // El instrumento ya existe, actualizar la cantidad en el catálogo
                    String sqlActualizar = "UPDATE tabla_instrumentos SET cantidad = cantidad + ?, agotado = ? WHERE codigo = ?";
                    try (PreparedStatement pstmtActualizar = connection.prepareStatement(sqlActualizar)) {
                        pstmtActualizar.setInt(1, cantidad);
                        pstmtActualizar.setBoolean(2, agotado);
                        pstmtActualizar.setInt(3, instrumento.getCodigo());
                        pstmtActualizar.executeUpdate();
                        System.out.println("Cantidad del instrumento actualizada en el catálogo.");
                    }
                } else {
                    // El instrumento no existe, insertarlo en la tabla
                    String sqlInsertar = "INSERT INTO tabla_instrumentos (codigo, nombre, tipo, cantidad, agotado) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmtInsertar = connection.prepareStatement(sqlInsertar)) {
                        pstmtInsertar.setInt(1, instrumento.getCodigo());
                        pstmtInsertar.setString(2, instrumento.getNombre());
                        pstmtInsertar.setString(3, instrumento.getTipoInstrumento());
                        pstmtInsertar.setInt(4, cantidad);
                        pstmtInsertar.setBoolean(5, agotado);
                        pstmtInsertar.executeUpdate();
                        System.out.println("Instrumento agregado al catálogo con éxito.");
                    }
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
     private static int obtenerSeleccion(String mensaje) {
        int seleccion = -1;
        do {
            System.out.print(mensaje);
            try {
                seleccion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer de entrada

                if (seleccion < -1 || seleccion > catalogoTotal.obtenerDiscosDesdeBD().size()) {
                    System.out.println("Error: Seleccione un número válido.");
                    seleccion = -1;
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                scanner.nextLine(); // Limpiar el buffer de entrada
            }
        } while (seleccion == -1);

        return seleccion;
    }
private static int obtenerCantidadVenta(Disco disco) {
        int cantidadVenta = -1;
        do {
            System.out.print("Ingrese la cantidad a vender (disponibles: " + catalogoTotal.obtenerCantidad(disco) + "): ");
            try {
                cantidadVenta = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer de entrada
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                scanner.nextLine(); // Limpiar el buffer de entrada
            }
        } while (cantidadVenta == -1);

        return cantidadVenta;
    }

    private static void eliminarInstrumentosDelCatalogo() {
        System.out.println("\n----- Eliminar Instrumentos del catalogo ------");

        // Muestra lista de instrumentos en el catálogo
        if (catalogoTotal.getCantidadInstrumentos() > 0) {
            System.out.println("Lista de instrumentos en el catalogo:");
            Instrumentos[] instrumentosEnCatalogo = catalogoTotal.getInstrumento();
            for (int i = 0; i < instrumentosEnCatalogo.length; i++) {
                Instrumentos instrumento = instrumentosEnCatalogo[i];
                if (instrumento != null) {
                    System.out.println((i + 1) + ". Nombre: " + instrumento.getNombre() + ", Tipo: " + instrumento.getTipoInstrumento());
                }
            }

            boolean numeroInstrumentoValido = false;
            int numeroInstrumento = 0;
            do {
                System.out.print("Seleccione el numero del instrumento a eliminar del catalogo: ");
                try {
                    numeroInstrumento = scanner.nextInt();
                    scanner.nextLine();

                    if (numeroInstrumento <= 0 || numeroInstrumento > instrumentosEnCatalogo.length || instrumentosEnCatalogo[numeroInstrumento - 1] == null) {
                        throw new IllegalArgumentException("Error: Seleccione un número valido del instrumento.");
                    }

                    numeroInstrumentoValido = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un número entero valido.");
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!numeroInstrumentoValido);

            Instrumentos instrumentoAEliminar = instrumentosEnCatalogo[numeroInstrumento - 1];
            if (instrumentoAEliminar != null) {
                catalogoTotal.eliminarInstrumento(instrumentoAEliminar);
                System.out.println("Instrumento eliminado del catalogo con exito.");
            } else {
                System.out.println("Instrumento no encontrado en el catalogo.");
            }
        } else {
            System.out.println("No hay instrumentos en el catalogo para eliminar.");
        }
    }

    private static void eliminarDiscoDelCatalogo() {
        System.out.println("\n----- Eliminar Disco del Catalogo -----");
        if (cantidadDiscosDisponibles(catalogoTotal.getDiscos()) > 0) {
            // Muestra lista de discos
            System.out.println("Lista de discos en el catalogo:");
            for (int i = 0; i < catalogoTotal.getDiscos().length; i++) {
                Disco disco = catalogoTotal.getDiscos()[i];
                if (disco != null) {
                    System.out.println((i + 1) + ". Codigo: " + disco.getCodigoDisco() + ", Nombre: " + disco.getNombreDisco());
                }
            }

            boolean numeroDiscoValido = false;
            int numeroDisco = 0;
            do {
                System.out.print("Seleccione el numero del disco a eliminar del catalogo: ");
                try {
                    numeroDisco = scanner.nextInt();
                    scanner.nextLine();

                    if (numeroDisco <= 0 || numeroDisco > catalogoTotal.getDiscos().length) {
                        throw new IllegalArgumentException("Error: Seleccione un numero valido del disco.");
                    }

                    numeroDiscoValido = true;
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un numero entero valido.");
                    scanner.nextLine();
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } while (!numeroDiscoValido);

            Disco discoSeleccionado = catalogoTotal.getDiscos()[numeroDisco - 1];
            if (discoSeleccionado != null) {
                catalogoTotal.eliminarDisco(discoSeleccionado);
                System.out.println("Disco eliminado del catalogo con exito.");
            } else {
                System.out.println("Disco no encontrado en el catalogo.");
            }
        } else {
            System.out.println("No hay discos registrados en el catalogo.");
        }
    }

 private static void venderDisco() {
        System.out.println("\n----- Vender Discos -----");

        List<Disco> discosDisponibles = catalogoTotal.obtenerDiscosDesdeBD();

        if (!discosDisponibles.isEmpty()) {
            System.out.println("Lista de discos disponibles:");
            for (int i = 0; i < discosDisponibles.size(); i++) {
                Disco disco = discosDisponibles.get(i);
                System.out.println((i + 1) + ". Código: " + disco.getCodigoDisco() + ", Nombre: " + disco.getNombreDisco());
            }

            int seleccionDisco = obtenerSeleccion("Seleccione el número del disco a vender: ");

            if (seleccionDisco >= 1 && seleccionDisco <= discosDisponibles.size()) {
                Disco discoSeleccionado = discosDisponibles.get(seleccionDisco - 1);

                if (catalogoTotal.obtenerCantidad(discoSeleccionado) > 0) {
                    System.out.println("Cantidad disponible antes de la venta: " + catalogoTotal.obtenerCantidad(discoSeleccionado));

                    int cantidadVenta = obtenerCantidadVenta(discoSeleccionado);

                    if (cantidadVenta > 0 && cantidadVenta <= catalogoTotal.obtenerCantidad(discoSeleccionado)) {
                        double precioTotal = cantidadVenta * discoSeleccionado.obtenerPrecio();
                        catalogoTotal.actualizarCantidad(discoSeleccionado, catalogoTotal.obtenerCantidad(discoSeleccionado) - cantidadVenta);

                        if (catalogoTotal.obtenerCantidad(discoSeleccionado) <= 0) {
                            catalogoTotal.actualizarEstado(discoSeleccionado, true);
                        }

                        actualizarCantidadDiscoEnBD(discoSeleccionado.getCodigoDisco(), catalogoTotal.obtenerCantidad(discoSeleccionado));

                        registrarVentaDisco(discoSeleccionado, cantidadVenta, precioTotal);

                        montoTotal += precioTotal;

                        System.out.println("Venta realizada con éxito.");
                        System.out.println("Disco vendido: " + discoSeleccionado.getNombreDisco());
                        System.out.println("Cantidad vendida: " + cantidadVenta);
                        System.out.println("Precio total: $" + precioTotal);
                        System.out.println("Monto total recaudado: $" + montoTotal);
                    } else {
                        System.out.println("Error: Cantidad de venta no válida.");
                    }
                } else {
                    System.out.println("Error: Disco agotado. No hay existencias disponibles para vender.");
                }
            } else {
                System.out.println("Error: Selección no válida.");
            }
        } else {
            System.out.println("No hay discos registrados para vender.");
        }
    }

private static void actualizarCantidadDiscoEnBD(int codigoDisco, int nuevaCantidad) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "UPDATE catalogo_discos SET cantidad = ? WHERE idDisco = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, nuevaCantidad);
            pstmt.setInt(2, codigoDisco);
            pstmt.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public static void registrarVentaDisco(Disco disco, int cantidad, double precioTotal) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "INSERT INTO ventas_discos (id_disco, cantidad, precio_total, fecha_venta) VALUES (?, ?, ?, NOW())";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, disco.getCodigoDisco());
            pstmt.setInt(2, cantidad);
            pstmt.setDouble(3, precioTotal);

            pstmt.executeUpdate();

            System.out.println("Venta registrada en la base de datos con éxito.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    private static void venderInstrumentos() {
    System.out.println("\n----- Vender Instrumentos -----");

    // Mostrar la lista de instrumentos disponibles
    System.out.println("Lista de instrumentos disponibles:");
    List<Instrumentos> instrumentosDisponibles = catalogoTotal.obtenerInstrumentosDesdeBD();

    for (int i = 0; i < instrumentosDisponibles.size(); i++) {
        Instrumentos instrumento = instrumentosDisponibles.get(i);
        System.out.println((i + 1) + ". " + instrumento.getNombre());
    }

    int seleccionInstrumento = obtenerSeleccion("Seleccione el número del instrumento a vender: ");

    // Verificar si la selección es válida
    if (seleccionInstrumento >= 1 && seleccionInstrumento <= instrumentosDisponibles.size()) {
        Instrumentos instrumentoSeleccionado = instrumentosDisponibles.get(seleccionInstrumento - 1);

        if (instrumentoSeleccionado != null && instrumentoSeleccionado.getCantidadStock() > 0) {
            int cantidadVenta = obtenerCantidadVenta(instrumentoSeleccionado);

            if (cantidadVenta > 0 && cantidadVenta <= instrumentoSeleccionado.getCantidadStock()) {
                // Realizar la venta
                double precioTotal = cantidadVenta * instrumentoSeleccionado.obtenerPrecio();
                instrumentoSeleccionado.actualizarStock(cantidadVenta);
                montoTotal += precioTotal;

                // Actualizar la base de datos con la nueva cantidad en stock
                actualizarCantidadInstrumentoEnBD(instrumentoSeleccionado.getCodigo(), instrumentoSeleccionado.getCantidadStock());

                System.out.println("Venta realizada con éxito.");
                System.out.println("Instrumento vendido: " + instrumentoSeleccionado.getNombre());
                System.out.println("Cantidad vendida: " + cantidadVenta);
                System.out.println("Precio total: $" + precioTotal);
                System.out.println("Monto total recaudado: $" + montoTotal);
            } else {
                System.out.println("Error: Cantidad de venta no válida.");
            }
        } else {
            System.out.println("Error: Instrumento no disponible o no encontrado.");
        }
    } else {
        System.out.println("Error: Selección no válida.");
    }
}

   private static void actualizarCantidadInstrumentoEnBD(int codigoInstrumento, int nuevaCantidad) {
    try (Connection connection = ConexionMySQL.obtenerConexion()) {
        String sql = "UPDATE tabla_instrumentos SET cantidad = ? WHERE codigo = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, nuevaCantidad);
            pstmt.setInt(2, codigoInstrumento);
            pstmt.executeUpdate();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    private static int obtenerCantidadVenta(Instrumentos instrumento) {
        int cantidadVenta = -1;
        do {
            System.out.print("Ingrese la cantidad a vender (disponibles: " + instrumento.getCantidadStock() + "): ");
            try {
                cantidadVenta = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer de entrada
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                scanner.nextLine(); // Limpiar el buffer de entrada
            }
        } while (cantidadVenta == -1);

        return cantidadVenta;
    }

    private static int obtenerIndiceDisponible(Object[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == null) {
                return i;
            }
        }
        return -1;
    }


    private static int cantidadDiscosDisponibles(Object[] array) {

        int cantidad = 0;

        for (Object item : array) {

            if (item != null) {
                cantidad++;

            }

        }
        return cantidad;

    }


    private static Cancion buscarCancionPorNumero(int numeroCancion) {
        for (Cancion cancion : cancionesTotal) {
            if (cancion != null && cancion.getNumeroCancion() == numeroCancion) {
                return cancion;
            }
        }
        return null;
    }



    private static void generarReporteInstrumentos() {
        Instrumentos[] instrumentosEnCatalogo = catalogoTotal.getInstrumento();

        if (catalogoTotal.getCantidadInstrumentos() > 0) {
            for (int i = 0; i < instrumentosEnCatalogo.length; i++) {
                Instrumentos instrumento = instrumentosEnCatalogo[i];
                if (instrumento != null) {
                    System.out.println("Numero de instrumento: " + (i + 1));
                    System.out.println("Nombre: " + instrumento.getNombre());
                    System.out.println("Tipo: " + instrumento.getTipoInstrumento());
                    System.out.println("Fabricacion: " + instrumento.getFabricacion());
                    System.out.println("Antigüedad: " + instrumento.getAntiguedad() + " años");
                    System.out.println("Precio: $" + instrumento.getPrecio());
                    System.out.println("Cantidad en stock: " + catalogoTotal.obtenerCantidad(instrumento));
                    System.out.println("Codigo: " + instrumento.getCodigo());
                    System.out.println("-----");
                }
            }
        } else {
            System.out.println("No hay instrumentos en el catálogo.");
        }
    }

    private static void mostrarArtistasLocales() {
        System.out.println("\n----- Reporte de artistas -----");
        for (Artista artista : artistasTotal) {

            if (artista != null) {
                System.out.println("DNI: " + artista.getDni());
                System.out.println("Nombre: " + artista.getNombre());
                System.out.println("Nacionalidad: " + artista.getNacionalidad());
            }

        }
    }

    private static void mostrarArtistasDesdeBaseDeDatos() {
        System.out.println("\n----- Reporte de artistas desde la base de datos -----");
        try (Connection connection = obtenerConexion()) {
            String sql = "SELECT dni, nombre, nacionalidad FROM artistas";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = pstmt.executeQuery()) {
                    Set<String> artistasDB = new HashSet<>();

                    while (resultSet.next()) {
                        String dni = resultSet.getString("dni");
                        String nombre = resultSet.getString("nombre");
                        String nacionalidad = resultSet.getString("nacionalidad");

                        artistasDB.add(dni);
                        System.out.println("DNI: " + dni);
                        System.out.println("Nombre: " + nombre);
                        System.out.println("Nacionalidad: " + nacionalidad);
                        System.out.println("------------------------------");
                    }

                    // Aquí puedes comparar con artistas locales y evitar duplicados
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void generarReporteArtistas() {
        mostrarArtistasLocales();
        mostrarArtistasDesdeBaseDeDatos();
    }

    private static void generarReporteCanciones() {
        System.out.println("\n----- Reporte de canciones -----");
        for (Cancion cancion : cancionesTotal) {
            if (cancion != null) {
                System.out.println("Numero de cancion: " + cancion.getNumeroCancion());
                System.out.println("Nombre de la cancion: " + cancion.getNombreCancion());
                System.out.println("Duracion: " + cancion.getDuracion() + " minutos");

            }
        }
    }

    private static void mostrarDiscosLocales() {
        System.out.println("\n----- Reporte de discos -----");
        for (Disco disco : discosTotal) {
            if (disco != null) {
                System.out.println("Codigo del disco: " + disco.getCodigoDisco());
                System.out.println("Nombre del disco: " + disco.getNombreDisco());
                System.out.println("Artista: " + disco.getArtista().getNombre());
                System.out.println("Canciones:");
                String[] canciones = disco.getListaCanciones();
                for (String cancion : canciones) {
                    if (cancion != null) {
                        System.out.println("- " + cancion);
                    }
                }
                System.out.println("------------------------------");
            }
        }
    }

    private static void mostrarDiscosDesdeBaseDeDatos() {
        System.out.println("\n----- Reporte de discos desde la base de datos -----");
        try (Connection connection = obtenerConexion()) {
            String sql = "SELECT codigoDisco, nombreDisco, idArtista FROM discos";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = pstmt.executeQuery()) {
                    Set<Integer> discosDB = new HashSet<>();

                    while (resultSet.next()) {
                        int codigoDisco = resultSet.getInt("codigoDisco");
                        String nombreDisco = resultSet.getString("nombreDisco");
                        String idArtista = resultSet.getString("idArtista");

                        discosDB.add(codigoDisco);
                        System.out.println("Codigo del disco: " + codigoDisco);
                        System.out.println("Nombre del disco: " + nombreDisco);
                        System.out.println("ID del Artista: " + idArtista);
                        System.out.println("------------------------------");
                    }

                    // Aquí puedes comparar con discos locales y evitar duplicados
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void generarReporteDiscos() {
        mostrarDiscosLocales();
        mostrarDiscosDesdeBaseDeDatos();
    }

//este método genera un reporte mostrando el monto total recaudado hasta el momento. 
//Es una forma de tener una visión rápida y clara de la cantidad de dinero que ha sido recaudada
//a través de las ventas de discos. 
    private static void generarReporteMontoRecaudado() {
        System.out.println("\n----- Reporte de monto recaudado -----");
        System.out.println("Monto recaudado del dia: $" + montoTotal);
    }

    private static void mostrarVentasLocales() {
        System.out.println("\n----- Reporte de ventas locales -----");
        for (Venta venta : ventasTotal) {
            if (venta != null) {
                System.out.println("Código de Venta: " + venta.getCodigoVenta());
                System.out.println("Monto Total: $" + venta.getMontoTotal());
                System.out.println("Fecha de Venta: " + venta.getFechaVenta());
                System.out.println("------------------------------");
            }
        }
    }

    private static void mostrarVentasDesdeBaseDeDatos() {
        System.out.println("\n----- Reporte de ventas desde la base de datos -----");
        try (Connection connection = obtenerConexion()) {
            String sql = "SELECT codigo_venta, monto_total, fecha_venta FROM ventas";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = pstmt.executeQuery()) {
                    Set<Integer> ventasDB = new HashSet<>();

                    while (resultSet.next()) {
                        int codigoVenta = resultSet.getInt("codigo_venta");
                        double montoTotal = resultSet.getDouble("monto_total");
                        String fechaVenta = resultSet.getString("fecha_venta");

                        ventasDB.add(codigoVenta);
                        System.out.println("Código de Venta: " + codigoVenta);
                        System.out.println("Monto Total: $" + montoTotal);
                        System.out.println("Fecha de Venta: " + fechaVenta);
                        System.out.println("------------------------------");
                    }

                    // Aquí puedes comparar con ventas locales y evitar duplicados
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void generarReporteVentas() {
        mostrarVentasLocales();
        mostrarVentasDesdeBaseDeDatos();
    }
}
