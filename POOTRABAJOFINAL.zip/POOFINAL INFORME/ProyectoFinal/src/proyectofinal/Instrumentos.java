
package proyectofinal;


public class Instrumentos implements Vendible {

    // Atributos
    private String nombre;
    private String fabricacion;
    private int antiguedad;
    private double precio;
    private String tipoInstrumento;
    private int cantidadStock;
    private int codigo;
    
    // Constructor
    public Instrumentos(String nombre, String fabricacion, int antiguedad, double precio,
                              String tipoInstrumento, int cantidadStock, int codigo) {
        this.nombre = nombre;
        this.fabricacion = fabricacion;
        this.antiguedad = antiguedad;
        this.precio = precio;
        this.tipoInstrumento = tipoInstrumento;
        this.cantidadStock = cantidadStock;
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFabricacion() {
        return fabricacion;
    }

    public void setFabricacion(String fabricacion) {
        this.fabricacion = fabricacion;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(String tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    
    @Override
    public double obtenerPrecio() {
        return precio;
    }
     public void establecerPrecio(double precio) {
        this.precio = precio;
    }

   public boolean vender(int cantidad) {
        if (cantidad <= cantidadStock) {
            cantidadStock -= cantidad;
            System.out.println("Venta realizada. Cantidad restante en stock: " + cantidadStock);
            return true;
        } else {
            System.out.println("No hay suficientes instrumentos en stock para la venta.");
            return false;
        }
    }

    // Método para calcular la antigüedad en base a un año de referencia
    public int calcularAntiguedad(int añoDeReferencia) {
        return añoDeReferencia - antiguedad;
    }

    public void actualizarStock(int cantidad) {
        cantidadStock += cantidad;
    }

    // Método para obtener información detallada del instrumento
    public String obtenerInformacion() {
        return "Instrumento: " + nombre +
                "\nFabricación: " + fabricacion +
                "\nAntigüedad: " + antiguedad + " anios" +
                "\nPrecio: $" + precio +
                "\nTipo de Instrumento: " + tipoInstrumento +
                "\nCantidad en Stock: " + cantidadStock +
                "\nCódigo: " + codigo;
    }
}
