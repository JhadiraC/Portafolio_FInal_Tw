
CREATE DATABASE IF NOT EXISTS poo_final;
USE poo_final;


CREATE TABLE IF NOT EXISTS artistas (
    dni VARCHAR(8) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    nacionalidad VARCHAR(50) NOT NULL
);


CREATE TABLE IF NOT EXISTS discos (
    codigoDisco INT AUTO_INCREMENT PRIMARY KEY,
    nombreDisco VARCHAR(100) NOT NULL,
    idArtista VARCHAR(8),
    precio DOUBLE NOT NULL,
    FOREIGN KEY (idArtista) REFERENCES artistas(dni)
);


CREATE TABLE IF NOT EXISTS canciones (
    numeroCancion INT PRIMARY KEY,
    nombreCancion VARCHAR(100) NOT NULL,
    duracion DOUBLE NOT NULL
);


CREATE TABLE IF NOT EXISTS canciones_discos (
    idDisco INT,
    numeroCancion INT,
    PRIMARY KEY (idDisco, numeroCancion),
    FOREIGN KEY (idDisco) REFERENCES discos(codigoDisco),
    FOREIGN KEY (numeroCancion) REFERENCES canciones(numeroCancion)
);


CREATE TABLE IF NOT EXISTS instrumentos (
    codigo INT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    fabricacion VARCHAR(50) NOT NULL,
    antiguedad INT NOT NULL,
    precio DOUBLE NOT NULL,
    tipo_instrumento VARCHAR(50) NOT NULL,
    cantidad_stock INT NOT NULL
);


CREATE TABLE IF NOT EXISTS catalogo_discos (
    idDisco INT PRIMARY KEY,
    cantidad INT NOT NULL,
    agotado BOOLEAN NOT NULL,
    FOREIGN KEY (idDisco) REFERENCES discos(codigoDisco)
);


CREATE TABLE IF NOT EXISTS catalogo_instrumentos (
    codigo INT PRIMARY KEY,
    cantidad INT NOT NULL,
    agotado BOOLEAN NOT NULL,
    FOREIGN KEY (codigo) REFERENCES instrumentos(codigo)
);


CREATE TABLE IF NOT EXISTS ventas_discos (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    id_disco INT,
    cantidad INT NOT NULL,
    precio_total DOUBLE NOT NULL,
    fecha_venta DATETIME NOT NULL,
    FOREIGN KEY (id_disco) REFERENCES discos(codigoDisco)
);


CREATE TABLE IF NOT EXISTS ventas_instrumentos (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    codigo_instrumento INT,
    cantidad INT NOT NULL,
    precio_total DOUBLE NOT NULL,
    fecha_venta DATETIME NOT NULL,
    FOREIGN KEY (codigo_instrumento) REFERENCES instrumentos(codigo)
);
select * from artistas;
select * from discos;
select * from canciones;
select * from canciones_discos;
select * from instrumentos;
select * from catalogo_discos;
select * from catalogo_instrumentos;
select * from ventas_discos;
select * from ventas_instrumentos;
delete from artistas;



